"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, MapPin, Clock, Check } from "lucide-react"
import { restaurantsData } from "@/data/restaurants"

export default function OrderTrackingPage() {
  const params = useParams()
  const router = useRouter()
  const restaurantId = params.id as string

  const restaurant = restaurantsData.find((r) => r.id === restaurantId)

  const [currentStep, setCurrentStep] = useState(1)
  const [estimatedTime, setEstimatedTime] = useState(30)

  if (!restaurant) {
    return <div className="container mx-auto px-4 py-8">Restaurant not found</div>
  }

  useEffect(() => {
    // Simulate order progress
    const timer = setTimeout(() => {
      if (currentStep < 4) {
        setCurrentStep(currentStep + 1)
        setEstimatedTime(Math.max(0, estimatedTime - 10))
      }
    }, 10000)

    return () => clearTimeout(timer)
  }, [currentStep, estimatedTime])

  const steps = [
    { id: 1, title: "Order Confirmed", description: "Your order has been received by the restaurant", icon: Check },
    { id: 2, title: "Preparing", description: "The restaurant is preparing your food", icon: Clock },
    { id: 3, title: "Out for Delivery", description: "Your order is on its way", icon: MapPin },
    { id: 4, title: "Delivered", description: "Enjoy your meal!", icon: Check },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="outline" onClick={() => router.back()} className="mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" /> Back
      </Button>

      <div className="max-w-2xl mx-auto">
        <Card className="mb-8">
          <CardHeader className={restaurant.color}>
            <CardTitle className="text-white">Order Tracking</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-2">Your order from {restaurant.name}</h2>
              <p className="text-gray-500">Order #12345 • {new Date().toLocaleString()}</p>
            </div>

            <div className="mb-8">
              <div className="relative">
                <div className="absolute left-4 top-0 h-full w-0.5 bg-gray-200"></div>

                {steps.map((step) => (
                  <div key={step.id} className="relative mb-8 last:mb-0">
                    <div className="flex items-start">
                      <div
                        className={`flex items-center justify-center w-8 h-8 rounded-full z-10 mr-4 ${
                          currentStep >= step.id ? `${restaurant.color} text-white` : "bg-gray-200"
                        }`}
                      >
                        <step.icon className="h-4 w-4" />
                      </div>
                      <div>
                        <h3 className="font-medium">{step.title}</h3>
                        <p className="text-sm text-gray-500">{step.description}</p>
                        {step.id === 3 && currentStep === 3 && (
                          <p className="text-sm mt-1">
                            Estimated arrival in <span className="font-medium">{estimatedTime} minutes</span>
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t pt-6">
              <h3 className="font-medium mb-4">Delivery Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500">Delivery Address</p>
                  <p className="text-sm">123 Main Street, Mbabane, Eswatini</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500">Contact</p>
                  <p className="text-sm">+268 7612 3456</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Order Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span>1 x Classic Burger</span>
                <span>E 65.00</span>
              </div>
              <div className="flex justify-between">
                <span>1 x French Fries</span>
                <span>E 30.00</span>
              </div>
              <div className="flex justify-between">
                <span>1 x Soda</span>
                <span>E 15.00</span>
              </div>

              <div className="border-t pt-4 mt-4">
                <div className="flex justify-between mb-2">
                  <span>Subtotal</span>
                  <span>E 110.00</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>Delivery Fee</span>
                  <span>E 15.00</span>
                </div>
                <div className="flex justify-between font-bold pt-2 border-t">
                  <span>Total</span>
                  <span>E 125.00</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
