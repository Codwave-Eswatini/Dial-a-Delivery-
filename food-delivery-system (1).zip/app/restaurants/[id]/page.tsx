"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ShoppingCart, Plus, Minus } from "lucide-react"
import { useCart } from "@/hooks/use-cart"
import { restaurantsData } from "@/data/restaurants"

export default function RestaurantPage() {
  const params = useParams()
  const router = useRouter()
  const { addToCart } = useCart()
  const restaurantId = params.id as string

  const restaurant = restaurantsData.find((r) => r.id === restaurantId)

  const [selectedCategory, setSelectedCategory] = useState(restaurant?.menuCategories[0].id || "")

  useEffect(() => {
    if (restaurant) {
      setSelectedCategory(restaurant.menuCategories[0].id)
    }
  }, [restaurant])

  if (!restaurant) {
    return <div className="container mx-auto px-4 py-8">Restaurant not found</div>
  }

  const handleAddToCart = (item: any) => {
    addToCart({
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: 1,
      restaurantId: restaurant.id,
      restaurantName: restaurant.name,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="outline" onClick={() => router.back()} className="mb-4">
          Back
        </Button>
        <div className={`relative h-64 w-full rounded-xl overflow-hidden mb-6`}>
          <div className={`absolute inset-0 ${restaurant.color} opacity-90`}></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-6">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{restaurant.name}</h1>
            <p className="text-white/90">{restaurant.description}</p>
            <div className="flex items-center mt-2 text-white/80">
              <span className="flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 mr-1"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                25-40 min
              </span>
              <span className="mx-2">•</span>
              <span>Free Delivery</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-3/4">
          <Tabs defaultValue={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="mb-6">
              {restaurant.menuCategories.map((category) => (
                <TabsTrigger key={category.id} value={category.id}>
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {restaurant.menuCategories.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {category.items.map((item) => (
                    <Card key={item.id}>
                      <CardContent className="p-4 flex">
                        <div className="flex-1">
                          <h3 className="font-semibold">{item.name}</h3>
                          <p className="text-sm text-gray-500 mb-2">{item.description}</p>
                          <p className={`font-bold ${restaurant.textColor}`}>E {item.price.toFixed(2)}</p>
                        </div>
                        <div className="ml-4 flex flex-col items-end justify-between">
                          {item.image && (
                            <div className="relative h-20 w-20 rounded-md overflow-hidden">
                              <Image
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                                fill
                                className="object-cover"
                              />
                            </div>
                          )}
                          <Button size="sm" onClick={() => handleAddToCart(item)} className={restaurant.buttonClass}>
                            <Plus className="h-4 w-4 mr-1" /> Add
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        <div className="lg:w-1/4">
          <CartSummary restaurant={restaurant} />
        </div>
      </div>
    </div>
  )
}

function CartSummary({ restaurant }: { restaurant: any }) {
  const { cart, removeFromCart, updateQuantity, clearCart } = useCart()
  const router = useRouter()

  const restaurantItems = cart.filter((item) => item.restaurantId === restaurant.id)

  const subtotal = restaurantItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const deliveryFee = 15
  const total = subtotal + deliveryFee

  const handleCheckout = () => {
    if (restaurantItems.length > 0) {
      router.push("/checkout")
    }
  }

  return (
    <div className="sticky top-4">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">Your Order</h3>
            <ShoppingCart className="h-5 w-5" />
          </div>

          {restaurantItems.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-gray-500">Your cart is empty</p>
              <p className="text-sm text-gray-400 mt-1">Add items to get started</p>
            </div>
          ) : (
            <>
              <div className="space-y-4 mb-6">
                {restaurantItems.map((item) => (
                  <div key={item.id} className="flex justify-between">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <div className="flex items-center border rounded-md mr-2">
                          <button
                            className="px-2 py-1"
                            onClick={() => {
                              if (item.quantity > 1) {
                                updateQuantity(item.id, item.quantity - 1)
                              } else {
                                removeFromCart(item.id)
                              }
                            }}
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="px-2">{item.quantity}</span>
                          <button className="px-2 py-1" onClick={() => updateQuantity(item.id, item.quantity + 1)}>
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                        <span>{item.name}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p>E {(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>E {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span>E {deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold pt-2 border-t">
                  <span>Total</span>
                  <span>E {total.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-6">
                <Button className={`w-full ${restaurant.buttonClass}`} onClick={handleCheckout}>
                  Checkout
                </Button>
                <Button variant="outline" className="w-full mt-2" onClick={() => clearCart()}>
                  Clear Cart
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
