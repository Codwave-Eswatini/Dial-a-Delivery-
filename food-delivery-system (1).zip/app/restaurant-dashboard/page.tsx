"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Check, X, Clock, ChevronDown, ChevronUp, Settings, LogOut } from "lucide-react"
import { restaurantsData } from "@/data/restaurants"

export default function RestaurantDashboard() {
  const [selectedRestaurant, setSelectedRestaurant] = useState(restaurantsData[0])
  const [orders, setOrders] = useState([
    {
      id: "ORD-001",
      customer: "John Doe",
      items: [
        { name: "Classic Burger", quantity: 1, price: 65 },
        { name: "French Fries", quantity: 1, price: 30 },
        { name: "Soda", quantity: 1, price: 15 },
      ],
      total: 110,
      status: "pending",
      time: "10:30 AM",
    },
    {
      id: "ORD-002",
      customer: "Jane Smith",
      items: [
        { name: "Pepperoni Pizza", quantity: 1, price: 95 },
        { name: "Garlic Bread", quantity: 1, price: 25 },
      ],
      total: 120,
      status: "preparing",
      time: "10:45 AM",
    },
    {
      id: "ORD-003",
      customer: "Michael Johnson",
      items: [
        { name: "Butter Chicken", quantity: 1, price: 95 },
        { name: "Naan", quantity: 2, price: 15 },
      ],
      total: 125,
      status: "ready",
      time: "11:00 AM",
    },
    {
      id: "ORD-004",
      customer: "Sarah Williams",
      items: [
        { name: "Chocolate Sundae", quantity: 2, price: 45 },
        { name: "Vanilla Milkshake", quantity: 1, price: 35 },
      ],
      total: 125,
      status: "delivered",
      time: "11:15 AM",
    },
  ])

  const [expandedOrder, setExpandedOrder] = useState<string | null>(null)

  const toggleOrderExpand = (orderId: string) => {
    if (expandedOrder === orderId) {
      setExpandedOrder(null)
    } else {
      setExpandedOrder(orderId)
    }
  }

  const updateOrderStatus = (orderId: string, newStatus: string) => {
    setOrders(orders.map((order) => (order.id === orderId ? { ...order, status: newStatus } : order)))
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold">Restaurant Dashboard</h1>
        <div className="flex items-center gap-4">
          <Button variant="outline" size="icon">
            <Settings className="h-5 w-5" />
          </Button>
          <Button variant="outline" size="icon">
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Restaurants</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {restaurantsData.map((restaurant) => (
                  <Button
                    key={restaurant.id}
                    variant={selectedRestaurant.id === restaurant.id ? "default" : "outline"}
                    className={`w-full justify-start ${selectedRestaurant.id === restaurant.id ? restaurant.buttonClass : ""}`}
                    onClick={() => setSelectedRestaurant(restaurant)}
                  >
                    {restaurant.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-3">
          <Card>
            <CardHeader className={selectedRestaurant.color}>
              <CardTitle className="text-white">{selectedRestaurant.name} Dashboard</CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              <Tabs defaultValue="orders">
                <TabsList className="mb-6">
                  <TabsTrigger value="orders">Orders</TabsTrigger>
                  <TabsTrigger value="menu">Menu Management</TabsTrigger>
                  <TabsTrigger value="analytics">Analytics</TabsTrigger>
                </TabsList>

                <TabsContent value="orders">
                  <div className="space-y-4">
                    {orders.map((order) => (
                      <Card key={order.id} className="overflow-hidden">
                        <div
                          className="p-4 cursor-pointer flex justify-between items-center"
                          onClick={() => toggleOrderExpand(order.id)}
                        >
                          <div className="flex items-center gap-4">
                            <OrderStatusBadge status={order.status} />
                            <div>
                              <h3 className="font-medium">{order.id}</h3>
                              <p className="text-sm text-gray-500">
                                {order.customer} • {order.time}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="font-medium">E {order.total.toFixed(2)}</span>
                            {expandedOrder === order.id ? (
                              <ChevronUp className="h-5 w-5" />
                            ) : (
                              <ChevronDown className="h-5 w-5" />
                            )}
                          </div>
                        </div>

                        {expandedOrder === order.id && (
                          <div className="p-4 pt-0 border-t">
                            <div className="mb-4">
                              <h4 className="font-medium mb-2">Order Items</h4>
                              <div className="space-y-2">
                                {order.items.map((item, index) => (
                                  <div key={index} className="flex justify-between">
                                    <span>
                                      {item.quantity} x {item.name}
                                    </span>
                                    <span>E {item.price.toFixed(2)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>

                            <div className="flex gap-2">
                              {order.status === "pending" && (
                                <>
                                  <Button
                                    size="sm"
                                    onClick={() => updateOrderStatus(order.id, "preparing")}
                                    className={selectedRestaurant.buttonClass}
                                  >
                                    Accept Order
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => updateOrderStatus(order.id, "cancelled")}
                                  >
                                    Reject
                                  </Button>
                                </>
                              )}

                              {order.status === "preparing" && (
                                <Button
                                  size="sm"
                                  onClick={() => updateOrderStatus(order.id, "ready")}
                                  className={selectedRestaurant.buttonClass}
                                >
                                  Mark as Ready
                                </Button>
                              )}

                              {order.status === "ready" && (
                                <Button
                                  size="sm"
                                  onClick={() => updateOrderStatus(order.id, "delivered")}
                                  className={selectedRestaurant.buttonClass}
                                >
                                  Mark as Delivered
                                </Button>
                              )}
                            </div>
                          </div>
                        )}
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="menu">
                  <div className="space-y-6">
                    {selectedRestaurant.menuCategories.map((category) => (
                      <div key={category.id}>
                        <h3 className="font-medium mb-4">{category.name}</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          {category.items.map((item) => (
                            <Card key={item.id}>
                              <CardContent className="p-4 flex justify-between items-center">
                                <div>
                                  <h4 className="font-medium">{item.name}</h4>
                                  <p className="text-sm text-gray-500">{item.description}</p>
                                  <p className={`font-bold ${selectedRestaurant.textColor}`}>
                                    E {item.price.toFixed(2)}
                                  </p>
                                </div>
                                <Button variant="outline" size="sm">
                                  Edit
                                </Button>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </div>
                    ))}

                    <Button className={selectedRestaurant.buttonClass}>Add New Item</Button>
                  </div>
                </TabsContent>

                <TabsContent value="analytics">
                  <div className="text-center py-12">
                    <p className="text-gray-500">Analytics dashboard coming soon</p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

function OrderStatusBadge({ status }: { status: string }) {
  switch (status) {
    case "pending":
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          <Clock className="h-3 w-3 mr-1" /> Pending
        </Badge>
      )
    case "preparing":
      return (
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          <Clock className="h-3 w-3 mr-1" /> Preparing
        </Badge>
      )
    case "ready":
      return (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          <Check className="h-3 w-3 mr-1" /> Ready
        </Badge>
      )
    case "delivered":
      return (
        <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
          <Check className="h-3 w-3 mr-1" /> Delivered
        </Badge>
      )
    case "cancelled":
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          <X className="h-3 w-3 mr-1" /> Cancelled
        </Badge>
      )
    default:
      return null
  }
}
