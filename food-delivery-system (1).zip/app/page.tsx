import Link from "next/link"
import { RestaurantCard } from "@/components/restaurant-card"
import { HeroSection } from "@/components/hero-section"

export default function Home() {
  const restaurants = [
    {
      id: "rocogo",
      name: "Rocogo",
      description: "Delicious gourmet burgers and sides",
      image: "/placeholder.svg?height=200&width=300",
      color: "bg-amber-600",
      textColor: "text-amber-600",
      category: "Burgers",
    },
    {
      id: "panarotis",
      name: "Panarotis",
      description: "Authentic Italian pizzas and pastas",
      image: "/placeholder.svg?height=200&width=300",
      color: "bg-red-600",
      textColor: "text-red-600",
      category: "Pizza",
    },
    {
      id: "little-india",
      name: "Little India",
      description: "Flavorful authentic Indian cuisine",
      image: "/placeholder.svg?height=200&width=300",
      color: "bg-orange-600",
      textColor: "text-orange-600",
      category: "Indian",
    },
    {
      id: "milkylane",
      name: "MilkyLane",
      description: "Premium ice cream and desserts",
      image: "/placeholder.svg?height=200&width=300",
      color: "bg-blue-500",
      textColor: "text-blue-500",
      category: "Ice Cream",
    },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <HeroSection />
      <h2 className="text-2xl font-bold mt-12 mb-6">Our Restaurants</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {restaurants.map((restaurant) => (
          <Link href={`/restaurants/${restaurant.id}`} key={restaurant.id}>
            <RestaurantCard restaurant={restaurant} />
          </Link>
        ))}
      </div>
    </div>
  )
}
