"use client"

// =============================================
// IMPORTS
// =============================================
import React, { createContext, useContext, useState, useEffect, type ReactNode } from "react"
import Link from "next/link"
import Image from "next/image"
import { useParams, useRouter } from "next/navigation"
import {
  Search,
  ShoppingCart,
  Menu,
  X,
  User,
  Plus,
  Minus,
  Check,
  Clock,
  MapPin,
  Settings,
  LogOut,
  ArrowLeft,
} from "lucide-react"

// =============================================
// DATA
// =============================================
const restaurantsData = [
  {
    id: "rocogo",
    name: "Rocogo",
    description: "Delicious gourmet burgers and sides",
    image: "/placeholder.svg?height=200&width=300",
    color: "bg-amber-600",
    textColor: "text-amber-600",
    buttonClass: "bg-amber-600 hover:bg-amber-700",
    category: "Burgers",
    menuCategories: [
      {
        id: "burgers",
        name: "Burgers",
        items: [
          {
            id: "classic-burger",
            name: "Classic Burger",
            description: "Beef patty, lettuce, tomato, onion, and our special sauce",
            price: 65.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "cheese-burger",
            name: "Cheese Burger",
            description: "Beef patty, cheddar cheese, lettuce, tomato, onion, and our special sauce",
            price: 75.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "bacon-burger",
            name: "Bacon Burger",
            description: "Beef patty, bacon, cheddar cheese, lettuce, tomato, onion, and our special sauce",
            price: 85.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "mushroom-burger",
            name: "Mushroom Burger",
            description: "Beef patty, sautéed mushrooms, swiss cheese, lettuce, and truffle mayo",
            price: 90.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "sides",
        name: "Sides",
        items: [
          {
            id: "fries",
            name: "French Fries",
            description: "Crispy golden fries seasoned with our special salt",
            price: 30.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "onion-rings",
            name: "Onion Rings",
            description: "Crispy battered onion rings served with dipping sauce",
            price: 35.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "coleslaw",
            name: "Coleslaw",
            description: "Fresh cabbage, carrots, and our creamy dressing",
            price: 25.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "drinks",
        name: "Drinks",
        items: [
          {
            id: "soda",
            name: "Soda",
            description: "Your choice of Coca-Cola, Sprite, or Fanta",
            price: 15.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "milkshake",
            name: "Milkshake",
            description: "Creamy milkshake in vanilla, chocolate, or strawberry",
            price: 35.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
    ],
  },
  {
    id: "panarotis",
    name: "Panarotis",
    description: "Authentic Italian pizzas and pastas",
    image: "/placeholder.svg?height=200&width=300",
    color: "bg-red-600",
    textColor: "text-red-600",
    buttonClass: "bg-red-600 hover:bg-red-700",
    category: "Pizza",
    menuCategories: [
      {
        id: "pizzas",
        name: "Pizzas",
        items: [
          {
            id: "margherita",
            name: "Margherita",
            description: "Tomato sauce, mozzarella, and fresh basil",
            price: 80.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "pepperoni",
            name: "Pepperoni",
            description: "Tomato sauce, mozzarella, and pepperoni",
            price: 95.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "hawaiian",
            name: "Hawaiian",
            description: "Tomato sauce, mozzarella, ham, and pineapple",
            price: 90.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "vegetarian",
            name: "Vegetarian",
            description: "Tomato sauce, mozzarella, bell peppers, mushrooms, onions, and olives",
            price: 85.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "pastas",
        name: "Pastas",
        items: [
          {
            id: "spaghetti-bolognese",
            name: "Spaghetti Bolognese",
            description: "Spaghetti with beef bolognese sauce",
            price: 70.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "fettuccine-alfredo",
            name: "Fettuccine Alfredo",
            description: "Fettuccine with creamy alfredo sauce",
            price: 75.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "lasagna",
            name: "Lasagna",
            description: "Layers of pasta, beef bolognese, and cheese",
            price: 85.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "desserts",
        name: "Desserts",
        items: [
          {
            id: "tiramisu",
            name: "Tiramisu",
            description: "Classic Italian dessert with coffee-soaked ladyfingers and mascarpone",
            price: 45.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "panna-cotta",
            name: "Panna Cotta",
            description: "Creamy Italian dessert with berry compote",
            price: 40.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
    ],
  },
  {
    id: "little-india",
    name: "Little India",
    description: "Flavorful authentic Indian cuisine",
    image: "/placeholder.svg?height=200&width=300",
    color: "bg-orange-600",
    textColor: "text-orange-600",
    buttonClass: "bg-orange-600 hover:bg-orange-700",
    category: "Indian",
    menuCategories: [
      {
        id: "starters",
        name: "Starters",
        items: [
          {
            id: "samosas",
            name: "Samosas",
            description: "Crispy pastry filled with spiced potatoes and peas",
            price: 40.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "pakoras",
            name: "Pakoras",
            description: "Assorted vegetables dipped in chickpea batter and fried",
            price: 35.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "tandoori-chicken",
            name: "Tandoori Chicken",
            description: "Chicken marinated in yogurt and spices, cooked in a tandoor",
            price: 65.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "mains",
        name: "Main Courses",
        items: [
          {
            id: "butter-chicken",
            name: "Butter Chicken",
            description: "Tender chicken in a rich tomato and butter sauce",
            price: 95.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "palak-paneer",
            name: "Palak Paneer",
            description: "Cottage cheese cubes in a spinach gravy",
            price: 85.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "biryani",
            name: "Chicken Biryani",
            description: "Fragrant rice cooked with chicken and aromatic spices",
            price: 90.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "dal-makhani",
            name: "Dal Makhani",
            description: "Black lentils cooked with butter and cream",
            price: 70.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "breads",
        name: "Breads",
        items: [
          {
            id: "naan",
            name: "Naan",
            description: "Soft leavened flatbread baked in a tandoor",
            price: 15.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "garlic-naan",
            name: "Garlic Naan",
            description: "Naan topped with garlic and butter",
            price: 20.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "roti",
            name: "Roti",
            description: "Whole wheat flatbread",
            price: 12.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
    ],
  },
  {
    id: "milkylane",
    name: "MilkyLane",
    description: "Premium ice cream and desserts",
    image: "/placeholder.svg?height=200&width=300",
    color: "bg-blue-500",
    textColor: "text-blue-500",
    buttonClass: "bg-blue-500 hover:bg-blue-600",
    category: "Ice Cream",
    menuCategories: [
      {
        id: "ice-cream",
        name: "Ice Cream",
        items: [
          {
            id: "vanilla",
            name: "Vanilla",
            description: "Classic vanilla ice cream made with Madagascar vanilla",
            price: 25.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "chocolate",
            name: "Chocolate",
            description: "Rich chocolate ice cream made with Belgian chocolate",
            price: 25.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "strawberry",
            name: "Strawberry",
            description: "Creamy strawberry ice cream with real strawberry pieces",
            price: 25.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "mint-chocolate",
            name: "Mint Chocolate Chip",
            description: "Refreshing mint ice cream with chocolate chips",
            price: 30.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "sundaes",
        name: "Sundaes",
        items: [
          {
            id: "chocolate-sundae",
            name: "Chocolate Sundae",
            description: "Vanilla ice cream with hot fudge, whipped cream, and a cherry",
            price: 45.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "banana-split",
            name: "Banana Split",
            description: "Vanilla, chocolate, and strawberry ice cream with banana, toppings, and whipped cream",
            price: 55.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "brownie-sundae",
            name: "Brownie Sundae",
            description: "Warm chocolate brownie topped with vanilla ice cream and hot fudge",
            price: 50.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
      {
        id: "milkshakes",
        name: "Milkshakes",
        items: [
          {
            id: "vanilla-shake",
            name: "Vanilla Milkshake",
            description: "Creamy vanilla milkshake topped with whipped cream",
            price: 35.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "chocolate-shake",
            name: "Chocolate Milkshake",
            description: "Rich chocolate milkshake topped with whipped cream",
            price: 35.0,
            image: "/placeholder.svg?height=100&width=100",
          },
          {
            id: "strawberry-shake",
            name: "Strawberry Milkshake",
            description: "Sweet strawberry milkshake topped with whipped cream",
            price: 35.0,
            image: "/placeholder.svg?height=100&width=100",
          },
        ],
      },
    ],
  },
]

// =============================================
// UI COMPONENTS
// =============================================

// These would normally be imported from a UI library like shadcn/ui
// For simplicity, we're defining simplified versions here
const Button = ({ children, className = "", variant = "default", size = "default", onClick = () => {}, ...props }) => {
  const baseStyles =
    "inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:opacity-50"

  const variantStyles = {
    default: "bg-primary text-primary-foreground hover:bg-primary/90",
    outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
    ghost: "hover:bg-accent hover:text-accent-foreground",
  }

  const sizeStyles = {
    default: "h-10 px-4 py-2",
    sm: "h-9 px-3",
    lg: "h-11 px-8",
    icon: "h-10 w-10",
  }

  return (
    <button
      className={`${baseStyles} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`}
      onClick={onClick}
      {...props}
    >
      {children}
    </button>
  )
}

const Card = ({ children, className = "", ...props }) => {
  return (
    <div className={`rounded-lg border bg-card text-card-foreground shadow-sm ${className}`} {...props}>
      {children}
    </div>
  )
}

const CardHeader = ({ children, className = "", ...props }) => {
  return (
    <div className={`flex flex-col space-y-1.5 p-6 ${className}`} {...props}>
      {children}
    </div>
  )
}

const CardTitle = ({ children, className = "", ...props }) => {
  return (
    <h3 className={`text-2xl font-semibold leading-none tracking-tight ${className}`} {...props}>
      {children}
    </h3>
  )
}

const CardContent = ({ children, className = "", ...props }) => {
  return (
    <div className={`p-6 pt-0 ${className}`} {...props}>
      {children}
    </div>
  )
}

const CardFooter = ({ children, className = "", ...props }) => {
  return (
    <div className={`flex items-center p-6 pt-0 ${className}`} {...props}>
      {children}
    </div>
  )
}

const Input = ({ className = "", ...props }) => {
  return (
    <input
      className={`flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
      {...props}
    />
  )
}

const Label = ({ children, className = "", ...props }) => {
  return (
    <label
      className={`text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 ${className}`}
      {...props}
    >
      {children}
    </label>
  )
}

const Textarea = ({ className = "", ...props }) => {
  return (
    <textarea
      className={`flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 ${className}`}
      {...props}
    />
  )
}

const RadioGroup = ({ children, className = "", ...props }) => {
  return (
    <div className={`grid gap-2 ${className}`} {...props}>
      {children}
    </div>
  )
}

const RadioGroupItem = ({ id, value, ...props }) => {
  return (
    <input
      type="radio"
      id={id}
      value={value}
      {...props}
      className="h-4 w-4 rounded-full border-gray-300 text-primary focus:ring-primary"
    />
  )
}

const Badge = ({ children, className = "", variant = "default", ...props }) => {
  const variantStyles = {
    default: "bg-primary text-primary-foreground",
    outline: "border border-input bg-background text-foreground",
  }

  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${variantStyles[variant]} ${className}`}
      {...props}
    >
      {children}
    </span>
  )
}

const Tabs = ({ children, defaultValue, className = "", ...props }) => {
  const [value, setValue] = useState(defaultValue)

  const onValueChange = (newValue) => {
    setValue(newValue)
    if (props.onValueChange) {
      props.onValueChange(newValue)
    }
  }

  // Clone children and pass value and onValueChange
  const childrenWithProps = React.Children.map(children, (child) => {
    if (React.isValidElement(child)) {
      if (child.type === TabsList || child.type === TabsContent) {
        return React.cloneElement(child, { value, onValueChange })
      }
    }
    return child
  })

  return (
    <div className={`${className}`} {...props}>
      {childrenWithProps}
    </div>
  )
}

const TabsList = ({ children, value, onValueChange, className = "", ...props }) => {
  // Clone children and pass value and onValueChange
  const childrenWithProps = React.Children.map(children, (child) => {
    if (React.isValidElement(child) && child.type === TabsTrigger) {
      return React.cloneElement(child, { value, onValueChange, isActive: child.props.value === value })
    }
    return child
  })

  return (
    <div
      className={`inline-flex h-10 items-center justify-center rounded-md bg-muted p-1 text-muted-foreground ${className}`}
      {...props}
    >
      {childrenWithProps}
    </div>
  )
}

const TabsTrigger = ({ children, value: tabValue, isActive, onValueChange, className = "", ...props }) => {
  return (
    <button
      className={`inline-flex items-center justify-center whitespace-nowrap rounded-sm px-3 py-1.5 text-sm font-medium ring-offset-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 ${isActive ? "bg-background text-foreground shadow-sm" : "hover:bg-background/50 hover:text-foreground"} ${className}`}
      onClick={() => onValueChange(tabValue)}
      {...props}
    >
      {children}
    </button>
  )
}

const TabsContent = ({ children, value: contentValue, value: currentValue, className = "", ...props }) => {
  if (contentValue !== currentValue) return null

  return (
    <div
      className={`mt-2 ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 ${className}`}
      {...props}
    >
      {children}
    </div>
  )
}

const Sheet = ({ children, ...props }) => {
  const [open, setOpen] = useState(false)

  // Clone children and pass open and setOpen
  const childrenWithProps = React.Children.map(children, (child) => {
    if (React.isValidElement(child)) {
      if (child.type === SheetTrigger) {
        return React.cloneElement(child, { onClick: () => setOpen(true) })
      }
      if (child.type === SheetContent) {
        return React.cloneElement(child, { open, onClose: () => setOpen(false) })
      }
    }
    return child
  })

  return <>{childrenWithProps}</>
}

const SheetTrigger = ({ children, onClick, ...props }) => {
  return React.cloneElement(children, { onClick, ...props })
}

const SheetContent = ({ children, open, onClose, ...props }) => {
  if (!open) return null

  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="fixed inset-0 bg-black/50" onClick={onClose} />
      <div className="fixed right-0 top-0 h-full w-3/4 max-w-md bg-background p-6 shadow-lg">
        <button
          className="absolute right-4 top-4 rounded-sm opacity-70 ring-offset-background transition-opacity hover:opacity-100"
          onClick={onClose}
        >
          <X className="h-4 w-4" />
          <span className="sr-only">Close</span>
        </button>
        {children}
      </div>
    </div>
  )
}

// =============================================
// CART CONTEXT
// =============================================
type CartItem = {
  id: string
  name: string
  price: number
  quantity: number
  restaurantId: string
  restaurantName: string
}

interface CartContextType {
  cart: CartItem[]
  addToCart: (item: CartItem) => void
  removeFromCart: (itemId: string) => void
  updateQuantity: (itemId: string, quantity: number) => void
  clearCart: () => void
  itemCount: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([])
  const [itemCount, setItemCount] = useState(0)

  // Load cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart)
        setCart(parsedCart)
        setItemCount(parsedCart.reduce((count: number, item: CartItem) => count + item.quantity, 0))
      } catch (error) {
        console.error("Failed to parse cart from localStorage:", error)
      }
    }
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart))
    setItemCount(cart.reduce((count, item) => count + item.quantity, 0))
  }, [cart])

  const addToCart = (newItem: CartItem) => {
    setCart((prevCart) => {
      // Check if item from same restaurant
      const hasItemsFromOtherRestaurant = prevCart.some(
        (item) => item.restaurantId !== newItem.restaurantId && prevCart.length > 0,
      )

      if (hasItemsFromOtherRestaurant) {
        if (
          confirm(
            "Your cart contains items from another restaurant. Would you like to clear your cart and add this item?",
          )
        ) {
          return [{ ...newItem, quantity: 1 }]
        } else {
          return prevCart
        }
      }

      // Check if item already exists in cart
      const existingItemIndex = prevCart.findIndex((item) => item.id === newItem.id)

      if (existingItemIndex >= 0) {
        // Update quantity of existing item
        const updatedCart = [...prevCart]
        updatedCart[existingItemIndex].quantity += 1
        return updatedCart
      } else {
        // Add new item
        return [...prevCart, { ...newItem, quantity: 1 }]
      }
    })
  }

  const removeFromCart = (itemId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== itemId))
  }

  const updateQuantity = (itemId: string, quantity: number) => {
    setCart((prevCart) => prevCart.map((item) => (item.id === itemId ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setCart([])
  }

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        itemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}

// =============================================
// COMPONENTS
// =============================================

// Header Component
function Header() {
  const { itemCount } = useCart()
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="text-2xl font-bold">
              Dial<span className="text-primary">a</span>Delivery
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-sm font-medium hover:text-primary">
              Home
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-primary">
              Restaurants
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-primary">
              About
            </Link>
            <Link href="#" className="text-sm font-medium hover:text-primary">
              Contact
            </Link>
          </nav>

          <div className="flex items-center space-x-4">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon" className="relative">
                  <ShoppingCart className="h-5 w-5" />
                  {itemCount > 0 && (
                    <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {itemCount}
                    </span>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <CartSheet />
              </SheetContent>
            </Sheet>

            <Button variant="outline" size="icon" className="hidden md:flex">
              <User className="h-5 w-5" />
            </Button>

            {/* Mobile Menu Button */}
            <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
              {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden py-4 border-t mt-4">
            <ul className="space-y-4">
              <li>
                <Link
                  href="/"
                  className="block text-sm font-medium hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Home
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="block text-sm font-medium hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Restaurants
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="block text-sm font-medium hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  About
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="block text-sm font-medium hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  Contact
                </Link>
              </li>
              <li>
                <Link
                  href="#"
                  className="block text-sm font-medium hover:text-primary"
                  onClick={() => setIsMenuOpen(false)}
                >
                  My Account
                </Link>
              </li>
            </ul>
          </nav>
        )}
      </div>
    </header>
  )
}

// Cart Sheet Component
function CartSheet() {
  const { cart, removeFromCart, updateQuantity, clearCart } = useCart()

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const deliveryFee = cart.length > 0 ? 15 : 0
  const total = subtotal + deliveryFee

  if (cart.length === 0) {
    return (
      <div className="h-full flex flex-col justify-center items-center">
        <ShoppingCart className="h-12 w-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-medium">Your cart is empty</h3>
        <p className="text-sm text-muted-foreground mt-1">Add items to get started</p>
      </div>
    )
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between pb-4 border-b">
        <h3 className="font-semibold text-lg">Your Cart</h3>
        <Button variant="ghost" size="sm" onClick={clearCart}>
          Clear All
        </Button>
      </div>

      <div className="flex-1 overflow-auto py-4">
        {cart.map((item) => (
          <div key={item.id} className="flex justify-between py-2 border-b">
            <div>
              <div className="flex items-center">
                <span className="font-medium">{item.quantity} x</span>
                <span className="ml-2">{item.name}</span>
              </div>
              <p className="text-sm text-muted-foreground">{item.restaurantName}</p>
            </div>
            <div className="flex items-center">
              <span className="mr-4">E {(item.price * item.quantity).toFixed(2)}</span>
              <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => removeFromCart(item.id)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="border-t pt-4 mt-auto">
        <div className="space-y-2">
          <div className="flex justify-between">
            <span>Subtotal</span>
            <span>E {subtotal.toFixed(2)}</span>
          </div>
          <div className="flex justify-between">
            <span>Delivery Fee</span>
            <span>E {deliveryFee.toFixed(2)}</span>
          </div>
          <div className="flex justify-between font-bold pt-2 border-t">
            <span>Total</span>
            <span>E {total.toFixed(2)}</span>
          </div>
        </div>

        <Button className="w-full mt-4">
          <Link href="/checkout">Proceed to Checkout</Link>
        </Button>
      </div>
    </div>
  )
}

// Footer Component
function Footer() {
  return (
    <footer className="bg-gray-100">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-lg font-bold mb-4">Dial a Delivery</h3>
            <p className="text-sm text-gray-600">
              Order delicious meals from your favorite restaurants and have them delivered to your doorstep.
            </p>
          </div>

          <div>
            <h4 className="font-medium mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm text-gray-600 hover:text-primary">
                  Home
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-primary">
                  Restaurants
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-primary">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-primary">
                  Contact
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4">Legal</h4>
            <ul className="space-y-2">
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-primary">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-primary">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="#" className="text-sm text-gray-600 hover:text-primary">
                  Cookie Policy
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4">Contact Us</h4>
            <address className="not-italic text-sm text-gray-600">
              <p>Mbabane, Eswatini</p>
              <p className="mt-2">Email: info@dialadelivery.sz</p>
              <p className="mt-1">Phone: +268 2404 1234</p>
            </address>
          </div>
        </div>

        <div className="border-t mt-8 pt-6 text-center text-sm text-gray-600">
          <p>&copy; {new Date().getFullYear()} Dial a Delivery. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

// Hero Section Component
function HeroSection() {
  return (
    <div className="relative bg-gray-900 rounded-xl overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-gray-900 to-transparent z-10" />
      <div className="relative z-20 px-6 py-16 md:py-24 md:px-12">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Dial a Delivery in Eswatini</h1>
          <p className="text-lg text-gray-200 mb-8">
            Order delicious meals from your favorite restaurants and have them delivered to your doorstep.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
              <input
                type="text"
                placeholder="Enter your delivery address"
                className="pl-10 pr-4 py-2 rounded-md w-full sm:w-80 focus:outline-none focus:ring-2 focus:ring-primary"
              />
            </div>
            <Button>Find Food</Button>
          </div>
        </div>
      </div>
    </div>
  )
}

// Restaurant Card Component
function RestaurantCard({ restaurant }) {
  return (
    <Card className="overflow-hidden transition-all duration-200 hover:shadow-lg h-full">
      <div className={`h-2 ${restaurant.color}`} />
      <div className="relative h-48 w-full">
        <Image src={restaurant.image || "/placeholder.svg"} alt={restaurant.name} fill className="object-cover" />
      </div>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className={`text-xl font-bold ${restaurant.textColor}`}>{restaurant.name}</h3>
          <span className="text-xs px-2 py-1 bg-gray-100 rounded-full">{restaurant.category}</span>
        </div>
        <p className="text-gray-600 text-sm">{restaurant.description}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <div className="flex items-center text-sm text-gray-500">
          <span className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 mr-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            25-40 min
          </span>
          <span className="mx-2">•</span>
          <span>Free Delivery</span>
        </div>
      </CardFooter>
    </Card>
  )
}

// Cart Summary Component
function CartSummary({ restaurant }) {
  const { cart, removeFromCart, updateQuantity, clearCart } = useCart()
  const router = useRouter()

  const restaurantItems = cart.filter((item) => item.restaurantId === restaurant.id)

  const subtotal = restaurantItems.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const deliveryFee = 15
  const total = subtotal + deliveryFee

  const handleCheckout = () => {
    if (restaurantItems.length > 0) {
      router.push("/checkout")
    }
  }

  return (
    <div className="sticky top-4">
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-bold">Your Order</h3>
            <ShoppingCart className="h-5 w-5" />
          </div>

          {restaurantItems.length === 0 ? (
            <div className="text-center py-6">
              <p className="text-gray-500">Your cart is empty</p>
              <p className="text-sm text-gray-400 mt-1">Add items to get started</p>
            </div>
          ) : (
            <>
              <div className="space-y-4 mb-6">
                {restaurantItems.map((item) => (
                  <div key={item.id} className="flex justify-between">
                    <div className="flex-1">
                      <div className="flex items-center">
                        <div className="flex items-center border rounded-md mr-2">
                          <button
                            className="px-2 py-1"
                            onClick={() => {
                              if (item.quantity > 1) {
                                updateQuantity(item.id, item.quantity - 1)
                              } else {
                                removeFromCart(item.id)
                              }
                            }}
                          >
                            <Minus className="h-3 w-3" />
                          </button>
                          <span className="px-2">{item.quantity}</span>
                          <button className="px-2 py-1" onClick={() => updateQuantity(item.id, item.quantity + 1)}>
                            <Plus className="h-3 w-3" />
                          </button>
                        </div>
                        <span>{item.name}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <p>E {(item.price * item.quantity).toFixed(2)}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="border-t pt-4 space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>E {subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Delivery Fee</span>
                  <span>E {deliveryFee.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold pt-2 border-t">
                  <span>Total</span>
                  <span>E {total.toFixed(2)}</span>
                </div>
              </div>

              <div className="mt-6">
                <Button className={`w-full ${restaurant.buttonClass}`} onClick={handleCheckout}>
                  Checkout
                </Button>
                <Button variant="outline" className="w-full mt-2" onClick={() => clearCart()}>
                  Clear Cart
                </Button>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

// Order Status Badge Component
function OrderStatusBadge({ status }) {
  switch (status) {
    case "pending":
      return (
        <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
          <Clock className="h-3 w-3 mr-1" /> Pending
        </Badge>
      )
    case "preparing":
      return (
        <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
          <Clock className="h-3 w-3 mr-1" /> Preparing
        </Badge>
      )
    case "ready":
      return (
        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
          <Check className="h-3 w-3 mr-1" /> Ready
        </Badge>
      )
    case "delivered":
      return (
        <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
          <Check className="h-3 w-3 mr-1" /> Delivered
        </Badge>
      )
    case "cancelled":
      return (
        <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
          <X className="h-3 w-3 mr-1" /> Cancelled
        </Badge>
      )
    default:
      return null
  }
}

// Order Summary Component
function OrderSummary({ cart, subtotal, deliveryFee, total }) {
  return (
    <Card className="sticky top-4">
      <CardHeader>
        <CardTitle>Order Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {cart.map((item) => (
            <div key={item.id} className="flex justify-between">
              <span>
                {item.quantity} x {item.name}
              </span>
              <span>E {(item.price * item.quantity).toFixed(2)}</span>
            </div>
          ))}

          <div className="border-t pt-4 mt-4">
            <div className="flex justify-between mb-2">
              <span>Subtotal</span>
              <span>E {subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between mb-2">
              <span>Delivery Fee</span>
              <span>E {deliveryFee.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-bold pt-2 border-t">
              <span>Total</span>
              <span>E {total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

// =============================================
// PAGES
// =============================================

// Home Page
function HomePage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <HeroSection />
      <h2 className="text-2xl font-bold mt-12 mb-6">Our Restaurants</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {restaurantsData.map((restaurant) => (
          <Link href={`/restaurants/${restaurant.id}`} key={restaurant.id}>
            <RestaurantCard restaurant={restaurant} />
          </Link>
        ))}
      </div>
    </div>
  )
}

// Restaurant Page
function RestaurantPage() {
  const params = useParams()
  const router = useRouter()
  const { addToCart } = useCart()
  const restaurantId = params.id

  const restaurant = restaurantsData.find((r) => r.id === restaurantId)

  const [selectedCategory, setSelectedCategory] = useState(restaurant?.menuCategories[0].id || "")

  useEffect(() => {
    if (restaurant) {
      setSelectedCategory(restaurant.menuCategories[0].id)
    }
  }, [restaurant])

  if (!restaurant) {
    return <div className="container mx-auto px-4 py-8">Restaurant not found</div>
  }

  const handleAddToCart = (item) => {
    addToCart({
      id: item.id,
      name: item.name,
      price: item.price,
      quantity: 1,
      restaurantId: restaurant.id,
      restaurantName: restaurant.name,
    })
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <Button variant="outline" onClick={() => router.back()} className="mb-4">
          Back
        </Button>
        <div className={`relative h-64 w-full rounded-xl overflow-hidden mb-6`}>
          <div className={`absolute inset-0 ${restaurant.color} opacity-90`}></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-6">
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{restaurant.name}</h1>
            <p className="text-white/90">{restaurant.description}</p>
            <div className="flex items-center mt-2 text-white/80">
              <span className="flex items-center">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4 mr-1"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
                25-40 min
              </span>
              <span className="mx-2">•</span>
              <span>Free Delivery</span>
            </div>
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-3/4">
          <Tabs defaultValue={selectedCategory} onValueChange={setSelectedCategory}>
            <TabsList className="mb-6">
              {restaurant.menuCategories.map((category) => (
                <TabsTrigger key={category.id} value={category.id}>
                  {category.name}
                </TabsTrigger>
              ))}
            </TabsList>

            {restaurant.menuCategories.map((category) => (
              <TabsContent key={category.id} value={category.id}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {category.items.map((item) => (
                    <Card key={item.id}>
                      <CardContent className="p-4 flex">
                        <div className="flex-1">
                          <h3 className="font-semibold">{item.name}</h3>
                          <p className="text-sm text-gray-500 mb-2">{item.description}</p>
                          <p className={`font-bold ${restaurant.textColor}`}>E {item.price.toFixed(2)}</p>
                        </div>
                        <div className="ml-4 flex flex-col items-end justify-between">
                          {item.image && (
                            <div className="relative h-20 w-20 rounded-md overflow-hidden">
                              <Image
                                src={item.image || "/placeholder.svg"}
                                alt={item.name}
                                fill
                                className="object-cover"
                              />
                            </div>
                          )}
                          <Button size="sm" onClick={() => handleAddToCart(item)} className={restaurant.buttonClass}>
                            <Plus className="h-4 w-4 mr-1" /> Add
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </div>

        <div className="lg:w-1/4">
          <CartSummary restaurant={restaurant} />
        </div>
      </div>
    </div>
  )
}

// Checkout Page
function CheckoutPage() {
  const { cart, clearCart } = useCart()
  const router = useRouter()
  const [orderPlaced, setOrderPlaced] = useState(false)
  const [paymentMethod, setPaymentMethod] = useState("cash")

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  const deliveryFee = cart.length > 0 ? 15 : 0
  const total = subtotal + deliveryFee

  const handleSubmit = (e) => {
    e.preventDefault()
    // Simulate order processing
    setTimeout(() => {
      setOrderPlaced(true)
      clearCart()
    }, 1500)
  }

  if (cart.length === 0 && !orderPlaced) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto text-center">
          <h1 className="text-2xl font-bold mb-4">Your cart is empty</h1>
          <p className="mb-6">Add some items to your cart before checking out.</p>
          <Button onClick={() => router.push("/")}>Browse Restaurants</Button>
        </div>
      </div>
    )
  }

  if (orderPlaced) {
    return (
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-md mx-auto text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <Check className="h-8 w-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold mb-4">Order Placed Successfully!</h1>
          <p className="mb-6">Thank you for your order. Your food is being prepared and will be delivered soon.</p>
          <Button onClick={() => router.push("/")}>Return to Home</Button>
        </div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="outline" onClick={() => router.back()} className="mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" /> Back
      </Button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit}>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Delivery Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2 sm:col-span-1">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input id="firstName" required className="mt-1" />
                  </div>
                  <div className="col-span-2 sm:col-span-1">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input id="lastName" required className="mt-1" />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input id="phone" type="tel" required className="mt-1" />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="address">Delivery Address</Label>
                    <Textarea id="address" required className="mt-1" />
                  </div>
                  <div className="col-span-2">
                    <Label htmlFor="instructions">Delivery Instructions (Optional)</Label>
                    <Textarea id="instructions" className="mt-1" placeholder="E.g., Gate code, landmark, etc." />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Payment Method</CardTitle>
              </CardHeader>
              <CardContent>
                <RadioGroup defaultValue="cash" value={paymentMethod} onValueChange={setPaymentMethod}>
                  <div className="flex items-center space-x-2 mb-4">
                    <RadioGroupItem value="cash" id="cash" />
                    <Label htmlFor="cash">Cash on Delivery</Label>
                  </div>
                  <div className="flex items-center space-x-2 mb-4">
                    <RadioGroupItem value="mobile" id="mobile" />
                    <Label htmlFor="mobile">Mobile Money</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="card" id="card" />
                    <Label htmlFor="card">Credit/Debit Card</Label>
                  </div>
                </RadioGroup>

                {paymentMethod === "mobile" && (
                  <div className="mt-4 p-4 border rounded-md">
                    <p className="text-sm mb-4">Enter your mobile money details:</p>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="mobileNumber">Mobile Number</Label>
                        <Input id="mobileNumber" className="mt-1" />
                      </div>
                    </div>
                  </div>
                )}

                {paymentMethod === "card" && (
                  <div className="mt-4 p-4 border rounded-md">
                    <p className="text-sm mb-4">Enter your card details:</p>
                    <div className="space-y-4">
                      <div>
                        <Label htmlFor="cardNumber">Card Number</Label>
                        <Input id="cardNumber" className="mt-1" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="expiry">Expiry Date</Label>
                          <Input id="expiry" placeholder="MM/YY" className="mt-1" />
                        </div>
                        <div>
                          <Label htmlFor="cvv">CVV</Label>
                          <Input id="cvv" className="mt-1" />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <div className="lg:hidden">
              <OrderSummary cart={cart} subtotal={subtotal} deliveryFee={deliveryFee} total={total} />
            </div>

            <Button type="submit" className="w-full">
              Place Order
            </Button>
          </form>
        </div>

        <div className="hidden lg:block">
          <OrderSummary cart={cart} subtotal={subtotal} deliveryFee={deliveryFee} total={total} />
        </div>
      </div>
    </div>
  )
}

// Order Tracking Page
function OrderTrackingPage() {
  const params = useParams()
  const router = useRouter()
  const restaurantId = params.id

  const restaurant = restaurantsData.find((r) => r.id === restaurantId)

  const [currentStep, setCurrentStep] = useState(1)
  const [estimatedTime, setEstimatedTime] = useState(30)

  if (!restaurant) {
    return <div className="container mx-auto px-4 py-8">Restaurant not found</div>
  }

  useEffect(() => {
    // Simulate order progress
    const timer = setTimeout(() => {
      if (currentStep < 4) {
        setCurrentStep(currentStep + 1)
        setEstimatedTime(Math.max(0, estimatedTime - 10))
      }
    }, 10000)

    return () => clearTimeout(timer)
  }, [currentStep, estimatedTime])

  const steps = [
    { id: 1, title: "Order Confirmed", description: "Your order has been received by the restaurant", icon: Check },
    { id: 2, title: "Preparing", description: "The restaurant is preparing your food", icon: Clock },
    { id: 3, title: "Out for Delivery", description: "Your order is on its way", icon: MapPin },
    { id: 4, title: "Delivered", description: "Enjoy your meal!", icon: Check },
  ]

  return (
    <div className="container mx-auto px-4 py-8">
      <Button variant="outline" onClick={() => router.back()} className="mb-6">
        <ArrowLeft className="h-4 w-4 mr-2" /> Back
      </Button>

      <div className="max-w-2xl mx-auto">
        <Card className="mb-8">
          <CardHeader className={restaurant.color}>
            <CardTitle className="text-white">Order Tracking</CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="mb-6">
              <h2 className="text-xl font-bold mb-2">Your order from {restaurant.name}</h2>
              <p className="text-gray-500">Order #12345 • {new Date().toLocaleString()}</p>
            </div>

            <div className="mb-8">
              <div className="relative">
                <div className="absolute left-4 top-0 h-full w-0.5 bg-gray-200"></div>

                {steps.map((step) => (
                  <div key={step.id} className="relative mb-8 last:mb-0">
                    <div className="flex items-start">
                      <div>
                        <div className="absolute left-0 top-0 flex h-8 w-8 items-center justify-center rounded-full bg-white shadow">
                          {step.id <= currentStep ? (
                            <div className="rounded-full bg-green-500 p-1">
                              <step.icon className="h-5 w-5 text-white" />
                            </div>
                          ) : (
                            <div className="rounded-full bg-gray-200 p-1">
                              <step.icon className="h-5 w-5 text-gray-500" />
                            </div>
                          )}
                        </div>
                      </div>
                      <div className="ml-12">
                        <h3 className="text-lg font-semibold">{step.title}</h3>
                        <p className="text-gray-500">{step.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6">
                <p className="text-gray-500">Estimated delivery time: {estimatedTime} minutes</p>
                <OrderStatusBadge
                  status={
                    currentStep === 1
                      ? "pending"
                      : currentStep === 2
                        ? "preparing"
                        : currentStep === 3
                          ? "ready"
                          : "delivered"
                  }
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Delivery Address</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <MapPin className="h-4 w-4 mr-2 text-gray-500" />
              <div>
                <p className="font-medium">123 Main St</p>
                <p className="text-gray-500">Mbabane, Eswatini</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

// Restaurant Dashboard Page
function RestaurantDashboardPage() {
  const [orders, setOrders] = useState([
    { id: 1, customer: "John Doe", time: "10:30 AM", status: "pending" },
    { id: 2, customer: "Jane Smith", time: "10:45 AM", status: "preparing" },
    { id: 3, customer: "Mike Johnson", time: "11:00 AM", status: "ready" },
    { id: 4, customer: "Emily Brown", time: "11:15 AM", status: "delivered" },
  ])

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold">Restaurant Dashboard</h1>
        <div className="flex items-center space-x-4">
          <Button variant="outline" size="icon">
            <Settings className="h-5 w-5" />
          </Button>
          <Button variant="outline" size="icon">
            <LogOut className="h-5 w-5" />
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Orders</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Order ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Customer
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Time
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Status
                  </th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {orders.map((order) => (
                  <tr key={order.id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">#{order.id}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{order.customer}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900">{order.time}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <OrderStatusBadge status={order.status} />
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <Button variant="outline" size="sm">
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

// =============================================
// APP
// =============================================

export default function App({ Component, pageProps }: any) {
  return (
    <CartProvider>
      <Header />
      <Component {...pageProps} />
      <Footer />
    </CartProvider>
  )
}
