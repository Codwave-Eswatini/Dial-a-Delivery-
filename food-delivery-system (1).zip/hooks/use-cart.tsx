"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type CartItem = {
  id: string
  name: string
  price: number
  quantity: number
  restaurantId: string
  restaurantName: string
}

interface CartContextType {
  cart: CartItem[]
  addToCart: (item: CartItem) => void
  removeFromCart: (itemId: string) => void
  updateQuantity: (itemId: string, quantity: number) => void
  clearCart: () => void
  itemCount: number
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>([])
  const [itemCount, setItemCount] = useState(0)

  // Load cart from localStorage on initial render
  useEffect(() => {
    const savedCart = localStorage.getItem("cart")
    if (savedCart) {
      try {
        const parsedCart = JSON.parse(savedCart)
        setCart(parsedCart)
        setItemCount(parsedCart.reduce((count: number, item: CartItem) => count + item.quantity, 0))
      } catch (error) {
        console.error("Failed to parse cart from localStorage:", error)
      }
    }
  }, [])

  // Save cart to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cart))
    setItemCount(cart.reduce((count, item) => count + item.quantity, 0))
  }, [cart])

  const addToCart = (newItem: CartItem) => {
    setCart((prevCart) => {
      // Check if item from same restaurant
      const hasItemsFromOtherRestaurant = prevCart.some(
        (item) => item.restaurantId !== newItem.restaurantId && prevCart.length > 0,
      )

      if (hasItemsFromOtherRestaurant) {
        if (
          confirm(
            "Your cart contains items from another restaurant. Would you like to clear your cart and add this item?",
          )
        ) {
          return [{ ...newItem, quantity: 1 }]
        } else {
          return prevCart
        }
      }

      // Check if item already exists in cart
      const existingItemIndex = prevCart.findIndex((item) => item.id === newItem.id)

      if (existingItemIndex >= 0) {
        // Update quantity of existing item
        const updatedCart = [...prevCart]
        updatedCart[existingItemIndex].quantity += 1
        return updatedCart
      } else {
        // Add new item
        return [...prevCart, { ...newItem, quantity: 1 }]
      }
    })
  }

  const removeFromCart = (itemId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.id !== itemId))
  }

  const updateQuantity = (itemId: string, quantity: number) => {
    setCart((prevCart) => prevCart.map((item) => (item.id === itemId ? { ...item, quantity } : item)))
  }

  const clearCart = () => {
    setCart([])
  }

  return (
    <CartContext.Provider
      value={{
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        itemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  )
}

export function useCart() {
  const context = useContext(CartContext)
  if (context === undefined) {
    throw new Error("useCart must be used within a CartProvider")
  }
  return context
}
