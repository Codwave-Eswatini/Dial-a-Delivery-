import { Card, CardContent, CardFooter } from "@/components/ui/card"
import Image from "next/image"

interface RestaurantCardProps {
  restaurant: {
    id: string
    name: string
    description: string
    image: string
    color: string
    textColor: string
    category: string
  }
}

export function RestaurantCard({ restaurant }: RestaurantCardProps) {
  return (
    <Card className="overflow-hidden transition-all duration-200 hover:shadow-lg h-full">
      <div className={`h-2 ${restaurant.color}`} />
      <div className="relative h-48 w-full">
        <Image src={restaurant.image || "/placeholder.svg"} alt={restaurant.name} fill className="object-cover" />
      </div>
      <CardContent className="p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className={`text-xl font-bold ${restaurant.textColor}`}>{restaurant.name}</h3>
          <span className="text-xs px-2 py-1 bg-gray-100 rounded-full">{restaurant.category}</span>
        </div>
        <p className="text-gray-600 text-sm">{restaurant.description}</p>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <div className="flex items-center text-sm text-gray-500">
          <span className="flex items-center">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-4 w-4 mr-1"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
              />
            </svg>
            25-40 min
          </span>
          <span className="mx-2">•</span>
          <span>Free Delivery</span>
        </div>
      </CardFooter>
    </Card>
  )
}
